#include <iostream>
#include <cstdlib>
#include <cmath>
#include <unistd.h>
#include <fstream>
#include <sstream>
#include "memtrace.h"
#include "string.h"
#include "film.h"
#include "art.h"
#include "filmcoll.h"
#include "gtest_lite.h"

using namespace std;

int main() {

  // Konstruktor tesztelése
  TEST(Filmek, Konstruktorok) {

    // Az összes típusú film konstruktorának tesztelése
    stringstream s1, s2, s3, s4, s5, s6;

    Film *f = new Film("Frida","Julie Taymor",123,2002,"A film Frida Kahlo mexikoi festono eletet mutatja be. 1922-ben, Mexikovarosban Frida elvezi diakeveit, a rajongo ferfiakat.",retCatStr("Art"));
    Hollywood *h = new Hollywood("Spider-Man","Sam Raimi",121,2002,"A film kozeppontjaban Peter Parker all, egy szerencsetlen, kulonc tinedzser, akinek az elete hatalmas fordulatot vesz, miutan megcsipi egy mutans pok.",false);
    Art *a = new Art("Leon the Professional","Luc Besson",133,1994,"Egy olasz bergyilkos, akinek nincsenek erzelmei, sok tejet iszik, ulve alszik es nagy rajongoja a Gene Kelly-filmeknek. O Leon (Jean Reno), aki a legjobb a varosban, egyedul dolgozik es maganyosan el.", true);
    European *e = new European("Intouchables","Olivier Nakache",108,2011,"Egy afrikai szarmazasu sofor bekesen vezet a kocsisorban, a parizsi ejszakaban, es idonkent figyelmes pillantast vet a mellette ulo, korszakallas, bajuszos, feher utasara.",false);
    FarEast *fe = new FarEast("Parasite","Bong Joon-ho",132,2019,"Kim Githek es csaladja egy felszuterenben lakik Szoulban, ahova nem sut be a nap, es rendszeresen az ablakuk ala vizelnek a reszegek. A csalad alkalmi munkakbol tengodik, mikozben nagyra toro almaik vannak.",retOrg("Korea"));
    Film *p = new Film();

    // Másoló konstruktor tesztelése
    Film copy = *p;

    f->print(s1);
    h->print(s2);
    a->print(s3);
    e->print(s4);
    fe->print(s5);
    p->print(s6);

    EXPECT_STREQ("Id: 0\nCim: Frida\nRendezo: Julie Taymor\nHossz: 123 perc\nKiadasi ev: 2002\nLeiras: A film Frida Kahlo mexikoi festono eletet mutatja be. 1922-ben, Mexikovarosban Frida elvezi diakeveit, a rajongo ferfiakat.\nKategoria: Art\n", s1.str().c_str());
    EXPECT_STREQ("Id: 0\nCim: Spider-Man\nRendezo: Sam Raimi\nHossz: 121 perc\nKiadasi ev: 2002\nLeiras: A film kozeppontjaban Peter Parker all, egy szerencsetlen, kulonc tinedzser, akinek az elete hatalmas fordulatot vesz, miutan megcsipi egy mutans pok.\nKategoria: Hollywood\nNyert-e dijat?: Nem nyertes\n\n", s2.str().c_str());
    EXPECT_STREQ("Id: 0\nCim: Leon the Professional\nRendezo: Luc Besson\nHossz: 133 perc\nKiadasi ev: 1994\nLeiras: Egy olasz bergyilkos, akinek nincsenek erzelmei, sok tejet iszik, ulve alszik es nagy rajongoja a Gene Kelly-filmeknek. O Leon (Jean Reno), aki a legjobb a varosban, egyedul dolgozik es maganyosan el.\nKategoria: Art\nNyert-e dijat?: ArtFilmAwards nyertes\n\n", s3.str().c_str());
    EXPECT_STREQ("Id: 0\nCim: Intouchables\nRendezo: Olivier Nakache\nHossz: 108 perc\nKiadasi ev: 2011\nLeiras: Egy afrikai szarmazasu sofor bekesen vezet a kocsisorban, a parizsi ejszakaban, es idonkent figyelmes pillantast vet a mellette ulo, korszakallas, bajuszos, feher utasara.\nKategoria: European\nNyert-e dijat?: Nem nyertes\n\n", s4.str().c_str());
    EXPECT_STREQ("Id: 0\nCim: Parasite\nRendezo: Bong Joon-ho\nHossz: 132 perc\nKiadasi ev: 2019\nLeiras: Kim Githek es csaladja egy felszuterenben lakik Szoulban, ahova nem sut be a nap, es rendszeresen az ablakuk ala vizelnek a reszegek. A csalad alkalmi munkakbol tengodik, mikozben nagyra toro almaik vannak.\nKategoria: FarEast\nA film eredete: Korea\n\n", s5.str().c_str());
    EXPECT_STREQ("Id: 0\nCim: \nRendezo: \nHossz: 0 perc\nKiadasi ev: 0\nLeiras: \nKategoria: Hollywood\n", s6.str().c_str());
    
    // Másoló konstruktor tesztelése
    EXPECT_EQ(p->getDescription(), copy.getDescription());

    delete f;
    delete h;
    delete a;
    delete e;
    delete fe;
    delete p;
  } ENDM

  // Üres gyűjtemény tesztelése
  TEST(FilmGyujtemeny, UresGyujtemeny) {
    FilmColl coll;
    stringstream s;
    unsigned int i = 0;
    EXPECT_EQ(i, coll.getFilmCollection().getnElement());
    coll.printAll(s);
    EXPECT_STREQ("\n", s.str().c_str());
  } ENDM

  return 0;
}